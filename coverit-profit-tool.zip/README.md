# CoverIt Profit Forecasting Tool

A simple Next.js app to estimate monthly profits based on load types and seasonal slowdowns.